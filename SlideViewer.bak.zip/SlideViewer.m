#import "SlideViewer.h"
#import "RoundedBox.h"

@implementation SlideViewer

- (id)initWithFrame:(NSRect)frameRect
{
	if ((self = [super initWithFrame:frameRect]) != nil) {
		// TO DO: Read in contents of file to array for slides (duh!)
		if (!worshipSlides)
			worshipSlides = [[NSArray alloc] initWithObjects: @"empty", nil];
		//worshipSlides = [[NSArray alloc] initWithObjects:
		//	@"holy uncreated One", @"Your beauty fills the skies", @"but the glory of Your majesty", @"is the mercy in Your eyes", @"worthy uncreated One",
		//	@"from heaven to earth come down", @"You laid aside Your royalty", @"to wear the sinner's crown", @"o great God be glorified", @"our lives laid down Yours magnified",
		//	@"o great God be lifted high", @"there is none like you", @"", @"Jesus", @"Savior",
		//	@"God's own son", @"risen reigning Lord", @"sustainer of the Universe", @"by the power of Your word", @"o great God be glorified", nil];
	}
	return self;
}

// Make slides read top to bottom
- (BOOL)isFlipped
{
	return YES;
}

// Calculate the height of a string for positioning
float heightForStringDrawing(NSString *myString, NSFont *desiredFont, float desiredWidth)
{
	NSTextStorage *textStorage = [[[NSTextStorage alloc] initWithString:myString] autorelease];
	NSTextContainer *textContainer = [[[NSTextContainer alloc] initWithContainerSize: NSMakeSize(desiredWidth, 1e7)] autorelease];
	NSLayoutManager *layoutManager = [[[NSLayoutManager alloc] init] autorelease];

	[textStorage addAttribute: NSFontAttributeName value: desiredFont range: NSMakeRange(0, [textStorage length])];
	[textContainer setLineFragmentPadding: 0.0]; // padding usually is not appropriate for string drawing

	[layoutManager addTextContainer: textContainer];
	[textStorage addLayoutManager: layoutManager];

	(void)[layoutManager glyphRangeForTextContainer: textContainer]; // force layout
	return [layoutManager usedRectForTextContainer: textContainer].size.height;
}

- (void)drawRect:(NSRect)rect
{
	//Set the background fill of the view
	[[NSColor colorWithCalibratedWhite:1.0 alpha:1.0] set];
	[NSBezierPath fillRect:rect];
	
	// Make the slide grid calculations
	[self updateGrid];
	
	// Set how many slides to draw
	NSRange rangeToDraw = [self slideIndexRangeForRect:rect];
	unsigned index;
	unsigned lastIndex = rangeToDraw.location + rangeToDraw.length;
	
	// Start building the slides
	for (index = rangeToDraw.location; index <= lastIndex; index++) {
		NSRect gridRect = [self centerScanRect:[self gridRectForIndex:index]];
		NSRect slideRect = [self rectCenteredInRect:gridRect withSize:NSMakeSize(160,140)];
		slideRect = [self centerScanRect:slideRect];
		
		/*
		NSBezierPath *selectionBorder = [NSBezierPath bezierPathWithRect:NSInsetRect(slideRect,-3.0,-3.0)];
		[selectionBorder setLineWidth:0.1];
		[[NSColor colorWithCalibratedWhite:0.2 alpha:1.0] set];
		[selectionBorder stroke];
		*/
		
		/*
		NSBezierPath *selectionBorder2 = [NSBezierPath bezierPathWithRect:NSInsetRect(gridRect,-3.0,-3.0)];
		[selectionBorder2 setLineWidth:1];
		[[NSColor colorWithCalibratedWhite:0.5 alpha:1.0] set];
		[selectionBorder2 stroke];
		*/
		
		/*
		RoundedBox *worshipSlide = [[RoundedBox alloc] initWithFrame: slideRect];
		[worshipSlide setTitle: @"Slide"];
		[self addSubview: worshipSlide];
		*/
		
		unsigned worshipTextViewHeight = heightForStringDrawing([worshipSlides objectAtIndex: index], [NSFont fontWithName:@"Lucida Grande Bold" size:13], 155.0)+2.0;
		NSRect worshipTextView = [self rectCenteredInRect:slideRect withSize:NSMakeSize(155, worshipTextViewHeight)];
		
		NSMutableParagraphStyle *worshipSlideTextPara = [[NSMutableParagraphStyle alloc] init];
			[worshipSlideTextPara setParagraphStyle:[NSParagraphStyle defaultParagraphStyle]];
			[worshipSlideTextPara setAlignment:NSCenterTextAlignment];
		
		NSMutableDictionary *worshipSlideTextAttrs = [NSMutableDictionary dictionaryWithObjectsAndKeys:
			[NSFont fontWithName:@"Lucida Grande Bold" size:13], NSFontAttributeName,
			worshipSlideTextPara, NSParagraphStyleAttributeName,
			nil];
			
		NSString *worshipSlideText = [[NSString alloc] initWithString: [worshipSlides objectAtIndex: index]];
		[worshipSlideText drawInRect:worshipTextView withAttributes: worshipSlideTextAttrs];
		
		// Construct rounded rect path
		float borderWidth = 2.0;
		NSRect bgRect = NSInsetRect(slideRect, borderWidth / 2.0, borderWidth / 2.0);
		bgRect = NSIntegralRect(bgRect);
		bgRect.origin.x += 0.5;
		bgRect.origin.y += 0.5;
		int minX = NSMinX(bgRect);
		int midX = NSMidX(bgRect);
		int maxX = NSMaxX(bgRect);
		int minY = NSMinY(bgRect);
		int midY = NSMidY(bgRect);
		int maxY = NSMaxY(bgRect);
		float radius = 4.0;
		NSBezierPath *bgPath = [NSBezierPath bezierPath];
		
		// Bottom edge and bottom-right curve
		[bgPath moveToPoint:NSMakePoint(midX, minY)];
		[bgPath appendBezierPathWithArcFromPoint:NSMakePoint(maxX, minY) 
										toPoint:NSMakePoint(maxX, midY) 
										radius:radius];
    
		// Right edge and top-right curve
		[bgPath appendBezierPathWithArcFromPoint:NSMakePoint(maxX, maxY) 
										toPoint:NSMakePoint(midX, maxY) 
										radius:radius];
    
		// Top edge and top-left curve
		[bgPath appendBezierPathWithArcFromPoint:NSMakePoint(minX, maxY) 
										toPoint:NSMakePoint(minX, midY) 
										radius:radius];
    
		// Left edge and bottom-left curve
		[bgPath appendBezierPathWithArcFromPoint:NSMakePoint(minX, minY) 
										toPoint:NSMakePoint(midX, minY) 
										radius:radius];
		[bgPath closePath];
		[[NSColor disabledControlTextColor] set];
		[bgPath setLineWidth:borderWidth];
		[bgPath stroke];
	}
}

- (void)updateGrid
{
	gridSize.width = 166;
	gridSize.height = 144;
	
	// Calculate the number of columns based on the current view width
	float viewWidth = [self frame].size.width;
	columns = viewWidth / gridSize.width;
	
	// There has to be at least one column
	if (1 > columns)
		columns = 1;
	
	// Add any extra pixel space to the column width
	gridSize.width += (viewWidth - (columns * gridSize.width)) / columns;
	
	// Calculate the number of rows based on the slide count
	int slideCount = [worshipSlides count];
	rows = slideCount / columns;
	
	// Any leftover slides get a new row for the scroll bar's sake
	if (0 < (slideCount % columns))
        rows++;
	
	// Calculate how high the view needs to be to enclose all rows
	float viewHeight = rows * gridSize.height;
	
	// Generate a scroll bar as needed
	NSScrollView *scroll = [self enclosingScrollView];
	if ((nil != scroll) && (viewHeight < [[scroll contentView] frame].size.height))
        viewHeight = [[scroll contentView] frame].size.height;
	
	// Set the new frame size
	[self setFrameSize:NSMakeSize(viewWidth, viewHeight)];
}

- (void) mouseDown:(NSEvent *) event
{
	mouseDown = YES;
	mouseDownPoint = [self convertPoint:[event locationInWindow] fromView:nil];
	mouseCurrentPoint = mouseDownPoint;

	unsigned				clickedIndex = [self slideIndexForPoint:mouseDownPoint];
	NSRect					slideRect = [self rectCenteredInRect:[self gridRectForIndex:clickedIndex] withSize:NSMakeSize(166,144)];
	//NSMutableIndexSet*		indexes = [[self selectionIndexes] mutableCopy];
	BOOL					imageHit = NSPointInRect(mouseDownPoint, slideRect);

	if (imageHit) {
		NSLog(@"Clicked Slide");
		//if ([indexes containsIndex:clickedIndex]) {
		//	[indexes removeIndex:clickedIndex];
		//} else {
		//	[indexes addIndex:clickedIndex];
		//}
	} else {
		NSLog(@"No Clicked Slide");
		//[indexes removeAllIndexes];
	}

	//[self setSelectionIndexes:indexes];
	//[indexes release];
}

- (NSRect)gridRectForIndex:(unsigned)index
{
	unsigned row = index / columns;
	unsigned column = index % columns;
	float x = column * gridSize.width;
	float y = row * gridSize.height;
	
	return NSMakeRect(x, y, gridSize.width, gridSize.height);
}

- (NSRect)rectCenteredInRect:(NSRect)rect withSize:(NSSize)size
{
    float x = rect.origin.x + ((rect.size.width - size.width) / 2);
    float y = rect.origin.y + ((rect.size.height - size.height) / 2);
    
    return NSMakeRect(x, y, size.width, size.height);
}

- (unsigned)slideIndexForPoint:(NSPoint)point
{
	unsigned column = point.x / gridSize.width;
	unsigned row = point.y / gridSize.height;
	
	return ((row * columns) + column);
}

- (NSRange)slideIndexRangeForRect:(NSRect)rect
{
    unsigned start = [self slideIndexForPoint:rect.origin];
	unsigned finish = [self slideIndexForPoint:NSMakePoint(NSMaxX(rect), NSMaxY(rect))];
	
    if (finish >= [worshipSlides count])
        finish = [worshipSlides count] - 1;
    
	return NSMakeRange(start, finish-start);
    
}

@end
