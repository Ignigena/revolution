/* SlideViewer */

#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>

@interface SlideViewer : NSView
{
	NSSize gridSize;
	NSArray *worshipSlides;
	
	float gridVertSpace;
	float gridHorzSpace;
	
	BOOL mouseDown;
	
	NSPoint mouseDownPoint;
	NSPoint mouseCurrentPoint;
	
	unsigned columns;
	unsigned rows;
}

- (void)updateGrid;

- (NSRect)gridRectForIndex:(unsigned)index;
- (NSRect)rectCenteredInRect:(NSRect)rect withSize:(NSSize)size;
- (unsigned)slideIndexForPoint:(NSPoint)point;
- (NSRange)slideIndexRangeForRect:(NSRect)rect;

@end
